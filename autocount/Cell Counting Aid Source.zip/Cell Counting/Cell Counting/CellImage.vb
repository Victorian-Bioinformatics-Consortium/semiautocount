﻿Imports System
Imports System.IO

Public Class CellImage
    Const N = 1000
    Const F = 10

    Public Structure Mark
        Public X As Integer
        Public Y As Integer
        Public infected As Boolean
    End Structure

    Dim aMark(N) As Mark
    Dim eP As Graphics
    Dim curI As Integer
    Dim path As String
    Dim imageFilename As String
    Dim saved As Boolean
    Dim maxCount As Integer = N
    Dim prevCount As Integer
    Dim prevInfected As Integer
    Dim gridOn As Boolean

    Public Sub Get_Filename(ByVal filename As String)
        imageFilename = filename
    End Sub

    Public Sub Get_Limit(ByVal max As Integer)
        maxCount = max
    End Sub

    Public Function Get_Prev() As Integer
        Return prevCount
    End Function

    Public Function Get_CurI() As Integer
        Return curI
    End Function

    Public Function Get_Max() As Integer
        Return maxCount
    End Function

    Public Function Get_Grid() As Boolean
        Return gridOn
    End Function

    Public Function Neighbour(ByVal x1 As Integer, ByVal x2 As Integer, ByVal y1 As Integer, ByVal y2 As Integer) As Boolean
        Dim hit As Boolean

        hit = False
        If (x1 = x2 - 1) And (y1 = y2 - 1) Then hit = True
        If (x1 = x2) And (y1 = y2 - 1) Then hit = True
        If (x1 = x2 + 1) And (y1 = y2 - 1) Then hit = True
        If (x1 = x2 - 1) And (y1 = y2) Then hit = True
        If (x1 = x2) And (y1 = y2) Then hit = True
        If (x1 = x2 + 1) And (y1 = y2) Then hit = True
        If (x1 = x2 - 1) And (y1 = y2 + 1) Then hit = True
        If (x1 = x2) And (y1 = y2 + 1) Then hit = True
        If (x1 = x2 + 1) And (y1 = y2 + 1) Then hit = True
        Return hit
    End Function

    Public Sub Initialise()
        Dim i As Integer
        For i = 1 To N
            aMark(i).X = N + 1
            aMark(i).Y = N + 1
            aMark(i).infected = False
        Next i
        curI = 1
    End Sub

    Public Sub Set_Grid(ByVal grid As Boolean)
        gridOn = grid
    End Sub


    Public Sub Save_file()
        Dim i As Integer, filename As String, position As Integer
        Dim path As String = "C:\Cell Counting\counting log.txt"
        Dim sa As StreamWriter

        position = InStr(imageFilename, ".")
        filename = Microsoft.VisualBasic.Left(imageFilename, position - 1) & ".txt"
        Using sw As StreamWriter = New StreamWriter(filename)
            sw.Write("Cell Counting Aid,")
            sw.Write(DateTime.Now)
            sw.Write(",")
            sw.Write(MDIParent1.ToolStripStatusLabel3.Text)
            sw.Write(",")
            sw.WriteLine(MDIParent1.ToolStripStatusLabel4.Text)
            For i = 1 To curI - 1
                sw.Write(aMark(i).X)
                sw.Write(",")
                sw.Write(aMark(i).Y)
                sw.Write(",")
                sw.WriteLine(aMark(i).infected)
            Next i
            sw.Close()
        End Using

        position = InStrRev(imageFilename, "\")
        position = InStrRev(imageFilename, "\", position - 1)
        If File.Exists(path) = False Then
            sa = File.CreateText(path)
            sa.Write(Mid(imageFilename, position))
            sa.Write(",")
            sa.Write(DateTime.Now)
            sa.Write(",")
            sa.Write(MDIParent1.ToolStripStatusLabel2.Text)
            sa.Write(",")
            sa.Write(MDIParent1.ToolStripStatusLabel3.Text)
            sa.Write(",")
            sa.Write(MDIParent1.ToolStripStatusLabel4.Text)
            sa.Write(",")
            sa.Write(MDIParent1.ToolStripStatusLabel5.Text)
            sa.Write(",")
            sa.WriteLine(MDIParent1.ToolStripStatusLabel6.Text)
            sa.Flush()
            sa.Close()
        Else
            sa = File.AppendText(path)
            sa.Write(Mid(imageFilename, position))
            sa.Write(",")
            sa.Write(DateTime.Now)
            sa.Write(",")
            sa.Write(MDIParent1.ToolStripStatusLabel2.Text)
            sa.Write(",")
            sa.Write(MDIParent1.ToolStripStatusLabel3.Text)
            sa.Write(",")
            sa.Write(MDIParent1.ToolStripStatusLabel4.Text)
            sa.Write(",")
            sa.Write(MDIParent1.ToolStripStatusLabel5.Text)
            sa.Write(",")
            sa.WriteLine(MDIParent1.ToolStripStatusLabel6.Text)
            sa.Flush()
            sa.Close()
        End If

        saved = True
    End Sub

    Private Sub CellImage_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Dim saveFileDialog1 As New SaveFileDialog()
        Dim name As String, position As Integer

        If saved = False Then
            saveFileDialog1.Filter = "Text files (*.txt)|*.txt"
            saveFileDialog1.FilterIndex = 1
            saveFileDialog1.RestoreDirectory = True
            position = InStrRev(imageFilename, "\")
            name = Microsoft.VisualBasic.Right(imageFilename, Len(imageFilename) - position)
            position = InStr(name, ".")
            saveFileDialog1.FileName = Microsoft.VisualBasic.Left(name, position - 1)

            If saveFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                imageFilename = saveFileDialog1.FileName
                Save_file()
            End If
        End If
        MDIParent1.opened = False
    End Sub


    Private Sub CellImage_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim i As Integer, j As Integer, lastNonEmpty As Integer, line As String
        Dim filename As String, sibbling As String, aString As String(), percent As Decimal

        filename = Microsoft.VisualBasic.Left(imageFilename, Len(imageFilename) - 4) & ".txt"
        If File.Exists(filename) Then
            Try
                Using sr As StreamReader = New StreamReader(filename)
                    curI = 1
                    line = sr.ReadLine() 'Get rid of first line'
                    line = sr.ReadLine()
                    If line Is Nothing = False Then
                        Do
                            aString = Split(line, ",")
                            lastNonEmpty = -1
                            For i = 0 To aString.Length - 1
                                If aString(i) <> "" Then
                                    lastNonEmpty = lastNonEmpty + 1
                                    aString(lastNonEmpty) = aString(i)
                                End If
                            Next
                            ReDim Preserve aString(lastNonEmpty)
                            aMark(curI).X = CInt(aString(0))
                            aMark(curI).Y = CInt(aString(1))
                            aMark(curI).infected = CBool(aString(2))
                            curI = curI + 1
                            line = sr.ReadLine()
                        Loop Until line Is Nothing
                        sr.Close()
                    End If
                End Using
            Catch err As Exception
                Console.WriteLine(filename & " could not be read.")
                Console.WriteLine(err.Message)
            End Try
        Else
            Initialise()
        End If

        prevCount = 0
        prevInfected = 0
        For i = 1 To F
            sibbling = Microsoft.VisualBasic.Left(filename, Len(filename) - 5) & Chr(96 + i) & Microsoft.VisualBasic.Right(filename, 4)
            If File.Exists(sibbling) And sibbling <> filename Then
                Try
                    Using sr As StreamReader = New StreamReader(sibbling)
                        line = sr.ReadLine()
                        If line Is Nothing = False Then
                            aString = Split(line, ",")
                            lastNonEmpty = -1
                            For j = 0 To aString.Length - 1
                                If aString(j) <> "" Then
                                    lastNonEmpty = lastNonEmpty + 1
                                    aString(lastNonEmpty) = aString(j)
                                End If
                            Next
                            ReDim Preserve aString(lastNonEmpty)
                            prevCount = prevCount + CInt(Mid(aString(2), InStr(aString(2), "=") + 2))
                            prevInfected = prevInfected + CInt(Mid(aString(3), InStr(aString(3), "=") + 2))
                        End If
                    End Using
                Catch err As Exception
                    Console.WriteLine(sibbling & " could not be read.")
                    Console.WriteLine(err.Message)
                End Try
            End If
        Next i
        j = 0
        For i = 1 To curI - 1
            If aMark(i).infected = True Then j = j + 1
        Next i
        If curI = 1 And prevCount = 0 Then
            percent = 0
        Else
            percent = (j + prevInfected) / (curI - 1 + prevCount) * 100
        End If
        MDIParent1.ToolStripStatusLabel2.Text = "Parasitaemia = " & CInt(percent) & " %"
        MDIParent1.ToolStripStatusLabel3.Text = "Current count = " & CInt(curI - 1)
        MDIParent1.ToolStripStatusLabel4.Text = "Current infected = " & CInt(j)
        MDIParent1.ToolStripStatusLabel5.Text = "Previous count = " & CInt(prevCount)
        MDIParent1.ToolStripStatusLabel6.Text = "Previous infected = " & CInt(prevInfected)

        Me.Text = imageFilename
        saved = True
        maxCount = N

        If (curI + prevCount - 1) > maxCount Then
            MsgBox("As the total count (current count + previous count) exceeds the maximum, the maximum count will be increased accordingly.")
            maxCount = curI + prevCount - 1
        End If
    End Sub

    Private Sub CellImage_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseClick
        Dim i As Integer, j As Integer, found As Boolean, percent As Decimal
        eP = Me.CreateGraphics()
        MDIParent1.ToolStripStatusLabel1.Text = "Pointer (" & e.X & "," & e.Y & ")"

        If ((Control.ModifierKeys And Keys.Control) = Keys.Control) Then
            If curI > 1 Then
                found = False
                i = 1
                Do
                    If Neighbour(aMark(i).X, e.X, aMark(i).Y, e.Y) = True Then
                        found = True
                        For j = i To curI - 1
                            aMark(j) = aMark(j + 1)
                        Next
                        curI = curI - 1
                        Me.Refresh()
                    End If
                    i = i + 1
                Loop Until found Or i = N + 1
            End If
        Else
            If (curI + prevCount) <= maxCount Then
                If e.Button = Windows.Forms.MouseButtons.Left Then
                    aMark(curI).X = e.X
                    aMark(curI).Y = e.Y
                    aMark(curI).infected = False
                    If Not (curI = N) Then curI = curI + 1
                    eP.DrawLine(Pens.Blue, e.X - 3, e.Y, e.X + 3, e.Y)
                    eP.DrawLine(Pens.Blue, e.X, e.Y - 3, e.X, e.Y + 3)
                Else
                    aMark(curI).X = e.X
                    aMark(curI).Y = e.Y
                    aMark(curI).infected = True
                    If Not (curI = N) Then curI = curI + 1
                    eP.DrawLine(Pens.Red, e.X - 3, e.Y, e.X + 3, e.Y)
                    eP.DrawLine(Pens.Red, e.X, e.Y - 3, e.X, e.Y + 3)

                End If
            Else
                MsgBox("You have reached the maximum count!")
            End If
        End If

        j = 0
        For i = 1 To curI - 1
            If aMark(i).infected = True Then j = j + 1
        Next i
        percent = (j + prevInfected) / (curI - 1 + prevCount) * 100
        MDIParent1.ToolStripStatusLabel2.Text = "Parasitaemia = " & CInt(percent) & " %"
        MDIParent1.ToolStripStatusLabel3.Text = "Current count = " & CInt(curI - 1)
        MDIParent1.ToolStripStatusLabel4.Text = "Current infected = " & CInt(j)
        eP.Dispose()
        saved = False
    End Sub

    Private Sub CellImage_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        Dim j As Integer
        eP = Me.CreateGraphics()

        If gridOn = True Then
            Dim myPen As Pen = New Pen(Color.Black)
            myPen.DashStyle = Drawing2D.DashStyle.Dot
            eP.DrawLine(myPen, 1, 100, 1024, 100)
            eP.DrawLine(myPen, 1, 200, 1024, 200)
            eP.DrawLine(myPen, 1, 300, 1024, 300)
            eP.DrawLine(myPen, 1, 400, 1024, 400)
            eP.DrawLine(myPen, 1, 500, 1024, 500)
            myPen.Dispose()
        End If

        If curI > 1 Then
            For j = 1 To curI
                If aMark(j).infected = True Then
                    eP.DrawLine(Pens.Red, aMark(j).X - 3, aMark(j).Y, aMark(j).X + 3, aMark(j).Y)
                    eP.DrawLine(Pens.Red, aMark(j).X, aMark(j).Y - 3, aMark(j).X, aMark(j).Y + 3)
                Else
                    eP.DrawLine(Pens.Blue, aMark(j).X - 3, aMark(j).Y, aMark(j).X + 3, aMark(j).Y)
                    eP.DrawLine(Pens.Blue, aMark(j).X, aMark(j).Y - 3, aMark(j).X, aMark(j).Y + 3)
                End If
            Next
        End If
        eP.Dispose()
    End Sub
End Class