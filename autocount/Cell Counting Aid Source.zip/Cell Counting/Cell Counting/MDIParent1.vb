﻿Imports System.Windows.Forms
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Printing

Public Class MDIParent1
    Public curFileName As String
    Public opened As Boolean
    Public currentDirectory As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments

    'Private Sub ShowNewForm(ByVal sender As Object, ByVal e As EventArgs) Handles NewToolStripMenuItem.Click
    ' Create a new instance of the child form.
    'Dim ChildForm As New System.Windows.Forms.Form
    ' Make it a child of this MDI form before showing it.
    '    ChildForm.MdiParent = Me

    '   m_ChildFormNumber += 1
    '   ChildForm.Text = "Window " & m_ChildFormNumber

    '    ChildForm.Show()
    'End Sub

    Private Sub OpenFile(ByVal sender As Object, ByVal e As EventArgs) Handles OpenToolStripMenuItem.Click, OpenToolStripButton.Click
        Dim OpenFileDialog As New OpenFileDialog
        Dim position As Integer
        If opened = True Then
            MsgBox("Please close the current file before opening another.")
        Else
            'OpenFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
            OpenFileDialog.InitialDirectory = currentDirectory
            OpenFileDialog.Filter = "Image files (*.bmp,*.tif,*.jpg)|*.*"
            If (OpenFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
                'Dim FileName As String = OpenFileDialog.FileName
                ' TODO: Add code here to open the file.
                curFileName = OpenFileDialog.FileName
                position = InStrRev(curFileName, "\")
                position = InStrRev(curFileName, "\", position - 1)
                currentDirectory = Microsoft.VisualBasic.Left(curFileName, position + 1)
                Dim returnedImage As Image
                returnedImage = Image.FromFile(curFileName)
                'curFileName = FileName
                CellImage.BackgroundImage = returnedImage
                CellImage.MdiParent = Me
                CellImage.Get_Filename(curFileName)
                CellImage.Show()
                opened = True
            End If
        End If
    End Sub

    Private Sub SaveToolStripButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveToolStripButton.Click
        Dim saveFileDialog1 As New SaveFileDialog()
        Dim name, tempFileName As String, position As Integer

        If opened = True Then
            saveFileDialog1.Filter = "Text files (*.txt)|*.txt"
            saveFileDialog1.FilterIndex = 1
            saveFileDialog1.RestoreDirectory = True
            position = InStrRev(curFileName, "\")
            name = Microsoft.VisualBasic.Right(curFileName, Len(curFileName) - position)
            position = InStr(name, ".")
            saveFileDialog1.FileName = Microsoft.VisualBasic.Left(name, position - 1)

            If saveFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                tempFileName = saveFileDialog1.FileName
                CellImage.Get_Filename(tempFileName)
                CellImage.Save_file()
            End If
        Else
            MsgBox("Sorry, there is nothing to save.")
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        Dim SaveFileDialog As New SaveFileDialog
        Dim name As String, position As Integer

        If opened = True Then
            SaveFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
            SaveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
            SaveFileDialog.RestoreDirectory = True
            position = InStrRev(curFileName, "\")
            name = Microsoft.VisualBasic.Right(curFileName, Len(curFileName) - position)
            position = InStr(name, ".")
            SaveFileDialog.FileName = Microsoft.VisualBasic.Left(name, position - 1)

            If (SaveFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
                Dim FileName As String = SaveFileDialog.FileName
                ' TODO: Add code here to save the current contents of the form to a file.
                CellImage.Get_Filename(FileName)
                CellImage.Save_file()
            End If
        Else
            MsgBox("Sorry, there is nothing to save.")
        End If
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        MsgBox("This program is written by Charles Ma and tested by Lev Kats" _
        & Chr(13) & "of Department of Microbiology, Monash University, Australia." _
        & Chr(13) & "Problems can be reported to Charles.Ma@monash.edu.")
    End Sub

    Private Sub PrintToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrintToolStripMenuItem.Click
        PrintForm1.Print()
        MsgBox("Printout is sent to the default printer.  Note that only part of the screen is printed.")
    End Sub


    Private Sub ExitToolsStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        CellImage.Close()
        Me.Close()
    End Sub

    Private Sub CloseAllToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        CellImage.Initialise()
        CellImage.Close()
        opened = False
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private m_ChildFormNumber As Integer

    Private Sub MDIParent1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PrintToolStripButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrintToolStripButton.Click
        PrintForm1.Print()
        MsgBox("Printout is sent to the default printer.  Note that only part of the screen is printed.")
    End Sub

    Private Sub SettingsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingsToolStripMenuItem.Click
        Parameter.Show()
    End Sub

    Private Sub ContentsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContentsToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub CloseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseToolStripMenuItem.Click
        CellImage.Initialise()
        CellImage.Close()
        opened = False
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        SaveToolStripButton_Click(sender, e)
    End Sub
End Class
