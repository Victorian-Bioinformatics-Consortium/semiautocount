﻿Imports System.Windows.Forms

Public Class Parameter
    Dim curI As Integer

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        If CInt(TextBox1.Text) > ((curI - 1) + CellImage.Get_Prev()) Then
            CellImage.Get_Limit(CInt(TextBox1.Text))
            CellImage.Set_Grid(CheckBox1.Checked)
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
            CellImage.Refresh()
        Else
            MsgBox("The maximum limit has to be larger than the current count + previous count.")
        End If
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub Parameter_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        curI = CellImage.Get_CurI()
        TextBox1.Text = CStr(CellImage.Get_Max())
        CheckBox1.Checked = CellImage.Get_Grid()
    End Sub
End Class